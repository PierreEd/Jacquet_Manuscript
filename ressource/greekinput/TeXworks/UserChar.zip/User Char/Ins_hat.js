// TeXworksScript
// Title: Insert ˆ (hat)
// Shortcut: Ctrl+Shift+^
// Description: Insert ˆ (hat)
// Author: Jean Hare
// Version: 0.1
// Date: 2012-11-23
// Script-Type: standalone
// Context: TeXDocument

TW.target.insertText("ˆ");
