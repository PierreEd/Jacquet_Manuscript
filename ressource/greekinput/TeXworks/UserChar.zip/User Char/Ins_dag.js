// TeXworksScript
// Title: Insert †
// Shortcut: Ctrl++
// Description: Insert \dag
// Author: Jean Hare
// Version: 0.1
// Date: 2012-11-23
// Script-Type: standalone
// Context: TeXDocument

TW.target.insertText("†");
