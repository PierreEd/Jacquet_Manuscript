// TeXworksScript
// Title: Insert \\quad
// Shortcut: Ctrl+Shift+space
// Description: Insert \quad
// Author: Jean Hare
// Version: 0.1
// Date: 2012-11-23
// Script-Type: standalone
// Context: TeXDocument

TW.target.insertText("\\quad ");
