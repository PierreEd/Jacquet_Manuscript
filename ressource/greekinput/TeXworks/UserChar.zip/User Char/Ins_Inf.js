// TeXworksScript
// Title: Insert ∞
// Shortcut: Ctrl+Shift+8
// Description: Insert ∞
// Author: Jean Hare
// Version: 0.1
// Date: 2012-11-28
// Script-Type: standalone
// Context: TeXDocument

TW.target.insertText("∞");
