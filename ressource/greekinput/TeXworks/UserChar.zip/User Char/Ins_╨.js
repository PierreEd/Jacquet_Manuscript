// TeXworksScript
// Title: Insert ð
// Shortcut: Ctrl+Alt+D
// Description: Insert ð
// Author: Jean Hare
// Version: 0.1
// Date: 2012-11-23
// Script-Type: standalone
// Context: TeXDocument

TW.target.insertText("ð");
